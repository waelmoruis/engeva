// ✅ هذا هو الكود الصحيح لملف supabase.js

// نتأكد إن المكتبة موجودة
if (typeof supabase === 'undefined') {
    console.error('❌ مكتبة Supabase غير موجودة')
    throw new Error('Supabase library not loaded')
}

// نستخدم namespaces مختلفة عشان ما تتعارض
window.AppSupabase = (function() {
    console.log('🔄 جاري تهيئة Supabase...')
    
    const CONFIG = {
        url: 'https://rapjueudcocrerrrzjgn.supabase.co',
        anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJhcGp1ZXVkY29jcmVycnJ6amduIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA3MzY1NDIsImV4cCI6MjA4NjMxMjU0Mn0.DG7Z_Ecv9SME-7UUCz56CKAjA9iJya2aGU-fy72jjyQ'
    }
    
    // إنشاء الاتصال
    const { createClient } = supabase
    const client = createClient(CONFIG.url, CONFIG.anonKey)
    
    console.log('✅ Supabase connected successfully')
    return client
})()

// تهيئة Supabase
