// js/config.js - أسهل ما يمكن

// كل الروابط في مكان واحد
const ROUTES = {
    // الصفحات الرئيسية
    home: 'index.html',
    
    // صفحات الأدمن
    admin: 'ADMIN/index.html',
    adminDashboard: 'ADMIN/dashboard.html',
    adminUsers: 'ADMIN/users.html',
    adminInventory: 'ADMIN/combined-data.html',
    
    // صفحات المستخدم
    user: 'user/login.html',
    userDashboard: 'user/dashboard.html',
    userInventory: 'user/inventory.html',
};

// دالة التوجيه - استخدمها في أي مكان
function goTo(page) {
    if (ROUTES[page]) {
        window.location.href = ROUTES[page];
    } else {
        alert('الصفحة غير موجودة');
    }
}

console.log('✅ الروابط جاهزة');