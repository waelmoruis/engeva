// ============================================
// ملف إدارة الطلبات - requests.js (النسخة النهائية المعدلة)
// ============================================

// متغيرات عامة
let allRequests = [];
let filteredRequests = [];
let totalCount = 0;
let activeFilters = {
    status: '', project: '', grade: '', groups: '',
    requestedBy: '', code: '', pr: '', actionManager: '', search: ''
};

window.allRequests = allRequests;
window.filteredRequests = filteredRequests;

// دالة آمنة لتحديث النص
function safeSetTextContent(id, value) {
    const element = document.getElementById(id);
    if (element) {
        element.textContent = value;
    } else {
        console.warn(`⚠️ عنصر بـ id "${id}" غير موجود في الصفحة`);
    }
}

// تحميل الطلبات
async function loadRequests() {
    console.log('🔄 تحميل الطلبات...');
    
    try {
        // التحقق من وجود supabaseClient
        if (!window.supabaseClient) {
            throw new Error('supabaseClient غير موجود');
        }
        
        // ✅ جلب العدد الإجمالي
        const { count: totalCount, error: totalError } = await window.supabaseClient
            .from('الطلبات')
            .select('*', { count: 'exact', head: true });
        
        if (totalError) throw totalError;
        
        // ✅ جلب عدد ON Request (تحت الطلب)
        const { count: pendingCount, error: pendingError } = await window.supabaseClient
            .from('الطلبات')
            .select('*', { count: 'exact', head: true })
            .ilike('Status', '%ON Request%');
        
        if (pendingError) throw pendingError;
        
        // ✅ جلب عدد Oracle Done
        const { count: oracleDoneCount, error: oracleDoneError } = await window.supabaseClient
            .from('الطلبات')
            .select('*', { count: 'exact', head: true })
            .ilike('Status', '%oracle done%');
        
        if (oracleDoneError) throw oracleDoneError;
        
        // ✅ جلب عدد Manager Done
        const { count: managerDoneCount, error: managerDoneError } = await window.supabaseClient
            .from('الطلبات')
            .select('*', { count: 'exact', head: true })
            .ilike('Status', '%manager done%');
        
        if (managerDoneError) throw managerDoneError;
        
        // ✅ جلب عدد Waiting Budget
        const { count: waitingBudgetCount, error: waitingBudgetError } = await window.supabaseClient
            .from('الطلبات')
            .select('*', { count: 'exact', head: true })
            .ilike('Status', '%waiting budget%');
        
        if (waitingBudgetError) throw waitingBudgetError;
        
        // ✅ جلب عدد المرفوضة
        const { count: rejectedCount, error: rejectedError } = await window.supabaseClient
            .from('الطلبات')
            .select('*', { count: 'exact', head: true })
            .ilike('Status', '%reject%');
        
        if (rejectedError) throw rejectedError;
        
        // ✅ تحديث الإحصائيات باستخدام الدالة الآمنة
        safeSetTextContent('totalRequests', totalCount.toLocaleString('ar-EG'));
        safeSetTextContent('pendingRequests', pendingCount.toLocaleString('ar-EG'));
        safeSetTextContent('oracleDoneCount', oracleDoneCount.toLocaleString('ar-EG'));
        safeSetTextContent('managerDoneCount', managerDoneCount.toLocaleString('ar-EG'));
        safeSetTextContent('waitingBudgetCount', waitingBudgetCount.toLocaleString('ar-EG'));
        safeSetTextContent('rejectedRequests', rejectedCount.toLocaleString('ar-EG'));
        
        console.log(`📊 إحصائيات حقيقية: معلق ${pendingCount}, Oracle ${oracleDoneCount}, Manager ${managerDoneCount}, Waiting Budget ${waitingBudgetCount}, مرفوض ${rejectedCount}, إجمالي ${totalCount}`);
        
        // عرض رسالة تحميل
        const tableBody = document.getElementById('requestsTableBody');
        if (tableBody) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="28" class="text-center py-8">
                        <div class="loading-spinner">
                            <i class="fas fa-spinner fa-spin fa-2x text-green-600 mb-3"></i>
                            <div>جاري تحميل ${totalCount.toLocaleString('ar-EG')} طلب...</div>
                        </div>
                    </td>
                </tr>
            `;
        }
        
        // جلب البيانات (أول 1000 سجل للسرعة)
        const { data, error } = await window.supabaseClient
            .from('الطلبات')
            .select('*')
            .order('id', { ascending: false })
            .limit(1000);

        if (error) throw error;

        allRequests = data || [];
        filteredRequests = [...allRequests];
        window.allRequests = allRequests;
        window.filteredRequests = filteredRequests;
        
        console.log(`✅ تم تحميل ${allRequests.length} طلب للعرض من أصل ${totalCount}`);
        
        // تحديث باقي العناصر
        if (typeof renderColumnList === 'function') {
            renderColumnList();
        }
        
        renderTable(filteredRequests);
        populateFilters(allRequests);
        getLastUpdateFromDB();

    } catch (error) {
        console.error('❌ خطأ في تحميل الطلبات:', error);
        const tableBody = document.getElementById('requestsTableBody');
        if (tableBody) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="28" class="text-center py-8 text-red-600">
                        <i class="fas fa-exclamation-circle fa-2x mb-3"></i>
                        <div>❌ فشل تحميل البيانات: ${error.message}</div>
                    </td>
                </tr>
            `;
        }
    }
}

// عرض الجدول
function renderTable(requests) {
    const thead = document.getElementById('tableHeader');
    const tbody = document.getElementById('requestsTableBody');
    
    if (!thead || !tbody) return;
    
    let headerRow = '<tr>';
    columns.forEach(col => {
        if (col.visible) headerRow += `<th class="${col.class}">${col.label}</th>`;
    });
    headerRow += '</tr>';
    thead.innerHTML = headerRow;

    if (!requests || requests.length === 0) {
        tbody.innerHTML = `<tr><td colspan="${columns.filter(c => c.visible).length}" class="text-center py-8">لا توجد طلبات تطابق البحث</td></tr>`;
        return;
    }

    // عرض عدد النتائج (فلتر)
    const resultText = document.getElementById('resultCount');
    if (resultText) {
        resultText.textContent = `عرض ${requests.length.toLocaleString('ar-EG')} من أصل ${totalCount.toLocaleString('ar-EG')} طلب`;
    }

    let rows = '';
    const displayRequests = requests.slice(0, 1000);
    
    displayRequests.forEach(req => {
        let row = '<tr onclick="openDetailsModal(\'' + req.id + '\')">';
        columns.forEach(col => {
            if (col.visible) {
                let value = req[col.field];
                if (col.field === 'Request Date' || col.field === 'Action Date') {
                    value = formatDate(value);
                } else if (col.field === 'Status') {
                    value = formatStatus(value);
                } else {
                    value = value || '—';
                }
                row += `<td class="${col.class}">${value}</td>`;
            }
        });
        row += '</tr>';
        rows += row;
    });
    
    if (requests.length > 1000) {
        rows += `
            <tr>
                <td colspan="${columns.filter(c => c.visible).length}" class="text-center py-4 text-gray-500 bg-gray-50">
                    <i class="fas fa-info-circle ml-1"></i>
                    يوجد ${(requests.length - 1000).toLocaleString('ar-EG')} طلب إضافي. استخدم الفلاتر للنتائج الأكثر دقة.
                </td>
            </tr>
        `;
    }
    
    tbody.innerHTML = rows;
    updateSelectedCount();
}

// تعبئة الفلاتر
function populateFilters(requests) {
    console.log('🔄 تعبئة الفلاتر من', requests.length, 'طلب');
    
    const projects = new Set();
    const grades = new Set();
    const groups = new Set();
    const requestedBy = new Set();
    const codes = new Set();
    const prs = new Set();
    const managers = new Set();
    
    requests.forEach(req => {
        if (req.Project) projects.add(req.Project);
        if (req.Grade) grades.add(req.Grade);
        if (req.groups) groups.add(req.groups);
        if (req['Requested by']) requestedBy.add(req['Requested by']);
        if (req.code) codes.add(req.code);
        if (req.pr) prs.add(req.pr);
        if (req['Action Manager']) managers.add(req['Action Manager']);
    });
    
    const projectsArray = [...projects].sort();
    const gradesArray = [...grades].sort();
    const groupsArray = [...groups].sort();
    const requestedByArray = [...requestedBy].sort();
    const codesArray = [...codes].sort();
    const prsArray = [...prs].sort();
    const managersArray = [...managers].sort();
    
    const projectFilter = document.getElementById('projectFilter');
    const gradeFilter = document.getElementById('gradeFilter');
    const groupsFilter = document.getElementById('groupsFilter');
    const requestedByFilter = document.getElementById('requestedByFilter');
    const codeFilter = document.getElementById('codeFilter');
    const prFilter = document.getElementById('prFilter');
    const actionManagerFilter = document.getElementById('actionManagerFilter');
    
    if (projectFilter) {
        projectFilter.innerHTML = '<option value="">الكل</option>';
        projectsArray.forEach(p => projectFilter.innerHTML += `<option value="${p}">${p}</option>`);
    }
    
    if (gradeFilter) {
        gradeFilter.innerHTML = '<option value="">الكل</option>';
        gradesArray.forEach(g => gradeFilter.innerHTML += `<option value="${g}">${g}</option>`);
    }
    
    if (groupsFilter) {
        groupsFilter.innerHTML = '<option value="">الكل</option>';
        groupsArray.forEach(g => groupsFilter.innerHTML += `<option value="${g}">${g}</option>`);
    }
    
    if (requestedByFilter) {
        requestedByFilter.innerHTML = '<option value="">الكل</option>';
        requestedByArray.forEach(r => requestedByFilter.innerHTML += `<option value="${r}">${r}</option>`);
    }
    
    if (codeFilter) {
        codeFilter.innerHTML = '<option value="">الكل</option>';
        codesArray.forEach(c => codeFilter.innerHTML += `<option value="${c}">${c}</option>`);
    }
    
    if (prFilter) {
        prFilter.innerHTML = '<option value="">الكل</option>';
        prsArray.forEach(p => prFilter.innerHTML += `<option value="${p}">${p}</option>`);
    }
    
    if (actionManagerFilter) {
        actionManagerFilter.innerHTML = '<option value="">الكل</option>';
        managersArray.forEach(m => actionManagerFilter.innerHTML += `<option value="${m}">${m}</option>`);
    }
}

// تطبيق الفلاتر المتقدمة
function applyAdvancedFilters() {
    activeFilters = {
        status: document.getElementById('statusFilter')?.value || '',
        project: document.getElementById('projectFilter')?.value || '',
        grade: document.getElementById('gradeFilter')?.value || '',
        groups: document.getElementById('groupsFilter')?.value || '',
        requestedBy: document.getElementById('requestedByFilter')?.value || '',
        code: document.getElementById('codeFilter')?.value || '',
        pr: document.getElementById('prFilter')?.value || '',
        actionManager: document.getElementById('actionManagerFilter')?.value || '',
        search: document.getElementById('searchInput')?.value.trim().toLowerCase() || ''
    };

    filteredRequests = allRequests.filter(req => {
        if (activeFilters.status) {
            const status = (req.Status || '').toLowerCase();
            if (!status.includes(activeFilters.status)) return false;
        }
        if (activeFilters.project && req.Project !== activeFilters.project) return false;
        if (activeFilters.grade && req.Grade !== activeFilters.grade) return false;
        if (activeFilters.groups && req.groups !== activeFilters.groups) return false;
        if (activeFilters.requestedBy && req['Requested by'] !== activeFilters.requestedBy) return false;
        if (activeFilters.code && req.code !== activeFilters.code) return false;
        if (activeFilters.pr && req.pr !== activeFilters.pr) return false;
        if (activeFilters.actionManager && req['Action Manager'] !== activeFilters.actionManager) return false;
        
        if (activeFilters.search) {
            let searchableText = '';
            columns.forEach(col => {
                const value = req[col.field];
                if (value !== null && value !== undefined) {
                    searchableText += ' ' + String(value).toLowerCase();
                }
            });
            if (req.id) searchableText += ' ' + req.id.toString().toLowerCase();
            return searchableText.includes(activeFilters.search);
        }
        return true;
    });

    console.log(`✅ الفلاتر أنتجت ${filteredRequests.length} نتيجة من أصل ${allRequests.length}`);
    
    renderTable(filteredRequests);
    updateActiveFiltersDisplay();
}

// مسح الفلاتر المتقدمة
function clearAdvancedFilters() {
    document.getElementById('statusFilter').value = '';
    document.getElementById('projectFilter').value = '';
    document.getElementById('gradeFilter').value = '';
    document.getElementById('groupsFilter').value = '';
    document.getElementById('requestedByFilter').value = '';
    document.getElementById('codeFilter').value = '';
    document.getElementById('prFilter').value = '';
    document.getElementById('actionManagerFilter').value = '';
    document.getElementById('searchInput').value = '';
    
    activeFilters = { status: '', project: '', grade: '', groups: '',
        requestedBy: '', code: '', pr: '', actionManager: '', search: '' };
    
    filteredRequests = [...allRequests];
    renderTable(filteredRequests);
    updateActiveFiltersDisplay();
}

// عرض الفلاتر النشطة
function updateActiveFiltersDisplay() {
    const container = document.getElementById('activeFiltersContainer');
    if (!container) return;
    
    let html = '';
    let activeCount = 0;
    
    const statusMap = {
        'on request': 'ON Request',
        'oracle done': 'Oracle Done',
        'reject data incomplete oracle': 'Reject data incomplete Oracle',
        'reject': 'Reject',
        'pending eng': 'Pending Eng',
        'pending eng new code': 'Pending Eng New Code',
        'on request new code': 'ON Request New Code',
        'waiting for coding': 'Waiting for coding',
        'waiting budget': 'Waiting Budget',
        'pending approval': 'Pending Approval',
        'manager done': 'Manager Done'
    };
    
    if (activeFilters.status) {
        const statusText = statusMap[activeFilters.status] || activeFilters.status;
        html += `<span class="filter-tag"><i class="fas fa-tag"></i> ${statusText} <i class="fas fa-times" onclick="removeAdvancedFilter('status')"></i></span>`;
        activeCount++;
    }
    if (activeFilters.project) {
        html += `<span class="filter-tag"><i class="fas fa-project-diagram"></i> ${activeFilters.project} <i class="fas fa-times" onclick="removeAdvancedFilter('project')"></i></span>`;
        activeCount++;
    }
    if (activeFilters.grade) {
        html += `<span class="filter-tag"><i class="fas fa-star"></i> ${activeFilters.grade} <i class="fas fa-times" onclick="removeAdvancedFilter('grade')"></i></span>`;
        activeCount++;
    }
    if (activeFilters.groups) {
        html += `<span class="filter-tag"><i class="fas fa-users"></i> ${activeFilters.groups} <i class="fas fa-times" onclick="removeAdvancedFilter('groups')"></i></span>`;
        activeCount++;
    }
    if (activeFilters.requestedBy) {
        html += `<span class="filter-tag"><i class="fas fa-user"></i> ${activeFilters.requestedBy} <i class="fas fa-times" onclick="removeAdvancedFilter('requestedBy')"></i></span>`;
        activeCount++;
    }
    if (activeFilters.code) {
        html += `<span class="filter-tag"><i class="fas fa-barcode"></i> ${activeFilters.code} <i class="fas fa-times" onclick="removeAdvancedFilter('code')"></i></span>`;
        activeCount++;
    }
    if (activeFilters.pr) {
        html += `<span class="filter-tag"><i class="fas fa-hashtag"></i> ${activeFilters.pr} <i class="fas fa-times" onclick="removeAdvancedFilter('pr')"></i></span>`;
        activeCount++;
    }
    if (activeFilters.actionManager) {
        html += `<span class="filter-tag"><i class="fas fa-user-tie"></i> ${activeFilters.actionManager} <i class="fas fa-times" onclick="removeAdvancedFilter('actionManager')"></i></span>`;
        activeCount++;
    }
    if (activeFilters.search) {
        html += `<span class="filter-tag"><i class="fas fa-search"></i> "${activeFilters.search}" <i class="fas fa-times" onclick="removeAdvancedFilter('search')"></i></span>`;
        activeCount++;
    }
    
    if (activeCount > 0) {
        html = `<span class="filter-tag bg-green-600 text-white">${activeCount} فلتر نشط</span>` + html;
    }
    
    container.innerHTML = html || '<div style="color: #a0aec0; font-size: 13px;">لا توجد فلاتر نشطة</div>';
}

function removeAdvancedFilter(filterName) {
    if (filterName === 'search') {
        document.getElementById('searchInput').value = '';
        activeFilters.search = '';
    } else {
        const element = document.getElementById(filterName + 'Filter');
        if (element) {
            element.value = '';
            activeFilters[filterName] = '';
        }
    }
    applyAdvancedFilters();
}

// فلتر البحث القديم
function filterRequests() {
    const searchTerm = document.getElementById('searchInput').value.trim().toLowerCase();
    const statusFilter = document.getElementById('oldStatusFilter')?.value || '';
    const projectFilter = document.getElementById('oldProjectFilter')?.value || '';
    const gradeFilter = document.getElementById('oldGradeFilter')?.value || '';

    const filtered = allRequests.filter(req => {
        if (statusFilter) {
            const s = (req.Status || '').toLowerCase();
            if (statusFilter === 'pending' && !s.includes('pending') && !s.includes('waiting') && !s.includes('انتظار')) return false;
            if (statusFilter === 'approved' && !s.includes('approve') && !s.includes('معتمد')) return false;
            if (statusFilter === 'rejected' && !s.includes('reject') && !s.includes('مرفوض')) return false;
            if (statusFilter === 'completed' && !s.includes('complete') && !s.includes('مكتمل')) return false;
            if (statusFilter === 'added' && !s.includes('added') && !s.includes('store')) return false;
            if (statusFilter === 'waiting' && !s.includes('waiting')) return false;
            if (statusFilter === 'oracle' && !s.includes('oracle')) return false;
            if (statusFilter === 'budget' && !s.includes('budget')) return false;
            if (statusFilter === 'on request' && !s.includes('on request')) return false;
            if (statusFilter === 'oracle done' && !s.includes('oracle done')) return false;
            if (statusFilter === 'reject data incomplete oracle' && !s.includes('reject data incomplete oracle')) return false;
            if (statusFilter === 'pending eng' && !s.includes('pending eng')) return false;
            if (statusFilter === 'pending eng new code' && !s.includes('pending eng new code')) return false;
            if (statusFilter === 'on request new code' && !s.includes('on request new code')) return false;
            if (statusFilter === 'waiting for coding' && !s.includes('waiting for coding')) return false;
            if (statusFilter === 'waiting budget' && !s.includes('waiting budget')) return false;
            if (statusFilter === 'pending approval' && !s.includes('pending approval')) return false;
            if (statusFilter === 'manager done' && !s.includes('manager done')) return false;
        }
        
        if (projectFilter && req.Project !== projectFilter) return false;
        if (gradeFilter && req.Grade !== gradeFilter) return false;
        
        if (searchTerm) {
            let searchableText = '';
            columns.forEach(col => {
                const value = req[col.field];
                if (value !== null && value !== undefined) {
                    searchableText += ' ' + String(value).toLowerCase();
                }
            });
            if (req.id) searchableText += ' ' + req.id.toString().toLowerCase();
            return searchableText.includes(searchTerm);
        }
        return true;
    });

    renderTable(filtered);
}

// جلب آخر تحديث
async function getLastUpdateFromDB() {
    try {
        const { data, error } = await window.supabaseClient
            .from('الطلبات')
            .select('updated_at')
            .order('updated_at', { ascending: false })
            .limit(1);

        if (!error && data && data[0]?.updated_at) {
            const lastUpdate = new Date(data[0].updated_at);
            safeSetTextContent('lastUpdateTime', lastUpdate.toLocaleDateString('ar-EG', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit'
            }));
        }
    } catch (error) {
        console.error('خطأ:', error);
    }
}

// جعل الدوال متاحة في النطاق العام
window.loadRequests = loadRequests;
window.renderTable = renderTable;
window.applyAdvancedFilters = applyAdvancedFilters;
window.clearAdvancedFilters = clearAdvancedFilters;
window.removeAdvancedFilter = removeAdvancedFilter;
window.filterRequests = filterRequests;
window.populateFilters = populateFilters;
window.getLastUpdateFromDB = getLastUpdateFromDB;

console.log('✅ تم تحميل ملف requests.js بنجاح');