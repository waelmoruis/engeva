// js/chat-widget.js - كود الدردشة الكامل مع حل مشكلة ظهور الرسائل
class ChatWidget {
    constructor(userType = 'admin') {
        this.userType = userType;
        this.isOpen = false;
        this.unreadCount = 0;
        this.privateUnreadCount = {};
        this.currentUser = null;
        this.currentPrivateUser = null;
        this.messages = [];
        this.privateMessages = {};
        this.onlineUsers = {};
        this.supabase = window.AppSupabase || window.supabase;
        this.currentTab = 'public'; // 'public' or 'private'
        
        // إضافات جديدة لمنع التكرار
        this.isUploading = false;        // قفل الرفع
        this.lastUploadTime = 0;          // آخر وقت رفع
        this.processedMessages = new Set(); // معرفات الرسائل المعالجة
        
        this.init();
    }
    
    async init() {
        await this.createTables();
        this.createWidget();
        this.addEventListeners();
        await this.loadUserData();
        this.addFileUploadButton();
    }
    
    // ✅ دالة إنشاء الجداول (معدلة - بدون rpc)
    async createTables() {
        console.log('✅ التحقق من الجداول...');
        
        const { error } = await this.supabase
            .from('private_messages')
            .select('id')
            .limit(1);
        
        if (error) {
            console.error('⚠️ ملاحظة:', error.message);
        } else {
            console.log('✅ جدول private_messages جاهز');
        }
    }
    
    // ✅ إضافة زر رفع الملفات
    addFileUploadButton() {
        setTimeout(() => {
            const footer = document.querySelector('.chat-popup-footer');
            if (!footer) return;
            
            const form = footer.querySelector('#chatForm');
            if (!form) return;
            
            const uploadBtn = document.createElement('button');
            uploadBtn.type = 'button';
            uploadBtn.id = 'fileUploadBtn';
            uploadBtn.innerHTML = '📎';
            uploadBtn.style.cssText = 'background: none; border: none; font-size: 24px; cursor: pointer; margin-left: 5px;';
            uploadBtn.title = 'رفع ملف';
            
            const fileInput = document.createElement('input');
            fileInput.type = 'file';
            fileInput.id = 'fileInput';
            fileInput.style.display = 'none';
            fileInput.accept = 'image/*,.pdf,.doc,.docx,.txt';
            
            uploadBtn.addEventListener('click', () => fileInput.click());
            
            fileInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    this.sendMessageWithFile(file);
                }
                fileInput.value = '';
            });
            
            form.prepend(uploadBtn);
            form.appendChild(fileInput);
        }, 1000);
    }
    
    // ✅ دالة ضغط الصور
    async compressImage(file) {
        return new Promise((resolve) => {
            try {
                if (typeof Compress === 'undefined') {
                    return resolve(file);
                }
                
                const compress = new Compress({
                    targetSize: 0.5,
                    quality: 0.8,
                    maxWidth: 1920,
                    maxHeight: 1080,
                    resize: true
                });
                
                compress.compress([file]).then((results) => {
                    const result = results[0];
                    const compressedFile = new File(
                        [result.data], 
                        file.name.replace(/\.[^/.]+$/, "") + ".jpg", 
                        { type: "image/jpeg" }
                    );
                    console.log(`📸 صورة مضغوطة: ${(file.size/1024).toFixed(2)}KB → ${(compressedFile.size/1024).toFixed(2)}KB`);
                    resolve(compressedFile);
                }).catch(() => resolve(file));
            } catch {
                resolve(file);
            }
        });
    }
    
    // ✅ دالة ضغط PDF
    async compressPDF(file) {
        try {
            if (typeof PDFLib === 'undefined') return file;
            
            const arrayBuffer = await file.arrayBuffer();
            const pdfDoc = await PDFLib.PDFDocument.load(arrayBuffer);
            const compressedPdfBytes = await pdfDoc.save({
                useObjectStreams: true,
                addDefaultPage: false
            });
            
            const compressedFile = new File(
                [compressedPdfBytes], 
                file.name.replace('.pdf', '-compressed.pdf'), 
                { type: 'application/pdf' }
            );
            
            console.log(`📄 PDF مضغوط: ${(file.size/1024).toFixed(2)}KB → ${(compressedFile.size/1024).toFixed(2)}KB`);
            return compressedFile;
        } catch {
            return file;
        }
    }
    
    // ✅ دالة اختيار الضغط حسب نوع الملف
    async compressFile(file) {
        if (file.size < 100 * 1024) return file;
        
        const fileType = file.type || file.name.split('.').pop().toLowerCase();
        
        if (fileType.startsWith('image/')) {
            return await this.compressImage(file);
        } else if (fileType === 'application/pdf' || fileType === 'pdf') {
            return await this.compressPDF(file);
        }
        return file;
    }
    
    // ✅ دالة رفع الملف إلى Supabase Storage
    async uploadToSupabase(file) {
        const cleanFileName = file.name.replace(/[^a-zA-Z0-9.]/g, '_');
        const filePath = `chat/${Date.now()}_${cleanFileName}`;
        
        try {
            const { error } = await this.supabase.storage
                .from('chat-files')
                .upload(filePath, file, {
                    cacheControl: '3600',
                    upsert: false
                });
            
            if (error) throw error;
            
            const { data: { publicUrl } } = this.supabase.storage
                .from('chat-files')
                .getPublicUrl(filePath);
            
            return {
                url: publicUrl,
                name: file.name,
                type: file.type
            };
            
        } catch (error) {
            console.error('خطأ في الرفع:', error);
            throw error;
        }
    }
    
    // ✅ دالة إرسال رسالة مع ملف (معدلة لدعم الرسائل الخاصة والعامة)
    async sendMessageWithFile(file) {
        if (this.isUploading) {
            alert('جاري رفع ملف بالفعل، انتظر قليلاً');
            return;
        }
        
        const now = Date.now();
        if (now - this.lastUploadTime < 3000) {
            alert('الرجاء الانتظار قليلاً قبل رفع ملف آخر');
            return;
        }
        
        if (!file || !this.currentUser) return;
        
        this.isUploading = true;
        this.lastUploadTime = now;
        
        try {
            const compressedFile = await this.compressFile(file);
            const fileData = await this.uploadToSupabase(compressedFile);
            
            const messageContent = document.getElementById('chatInput')?.value.trim() || '';
            
            const baseMessageData = {
                content: messageContent,
                file_url: fileData.url,
                file_type: fileData.type,
                file_name: fileData.name,
                created_at: new Date().toISOString()
            };
            
            let messageData;
            let tableName;
            let channelName;
            
            if (this.currentTab === 'public') {
                // رسالة عامة
                messageData = {
                    ...baseMessageData,
                    user_id: this.currentUser.id,
                    user_name: this.currentUser.full_name || this.currentUser.username,
                    user_role: this.currentUser.role
                };
                tableName = 'messages';
                channelName = this.publicChannel;
            } else {
                // رسالة خاصة - مهم جداً
                messageData = {
                    ...baseMessageData,
                    sender_id: this.currentUser.id,
                    receiver_id: this.currentPrivateUser,
                    sender_name: this.currentUser.full_name || this.currentUser.username,
                    sender_role: this.currentUser.role
                };
                tableName = 'private_messages';
                channelName = this.privateChannel;
            }
            
            console.log(`📝 حفظ في ${tableName}:`, messageData);
            
            // حفظ في قاعدة البيانات
            const { error } = await this.supabase
                .from(tableName)
                .insert([messageData]);
            
            if (error) throw error;
            
            console.log('✅ تم حفظ الرسالة بنجاح');
            
            // عرض الرسالة فوراً حسب نوعها
            if (this.currentTab === 'public') {
                this.displayMessage({
                    ...messageData,
                    user_name: this.currentUser.full_name || this.currentUser.username,
                    user_role: this.currentUser.role
                }, true);
            } else {
                this.displayPrivateMessage({
                    ...messageData,
                    sender_name: this.currentUser.full_name || this.currentUser.username,
                    sender_role: this.currentUser.role
                }, true);
            }
            
            // مسح حقل الإدخال
            if (document.getElementById('chatInput')) {
                document.getElementById('chatInput').value = '';
            }
            
        } catch (error) {
            console.error('❌ خطأ في رفع الملف:', error);
            alert('فشل رفع الملف: ' + error.message);
        } finally {
            this.isUploading = false;
        }
    }
    
    createWidget() {
        const btnClass = this.userType === 'admin' ? 'floating-chat-btn' : 'floating-chat-btn user';
        
        this.widget = document.createElement('div');
        this.widget.className = btnClass;
        this.widget.id = 'floatingChatBtn';
        this.widget.innerHTML = `
            <span class="chat-icon">💬</span>
            <span class="chat-badge" id="chatBadge" style="display: none;">0</span>
            <span class="private-chat-badge" id="privateChatBadge" style="display: none;">0</span>
        `;
        
        this.popup = document.createElement('div');
        this.popup.className = 'chat-popup';
        this.popup.id = 'chatPopup';
        
        const headerClass = this.userType === 'admin' ? 'chat-popup-header' : 'chat-popup-header user';
        
        this.popup.innerHTML = `
            <div class="${headerClass}">
                <div>
                    <h3>💬 الدردشة</h3>
                    <div class="online-indicator">
                        <span class="online-dot"></span>
                        <span id="onlineCount">0</span> متصل
                    </div>
                </div>
                <button class="close-btn" onclick="chatWidget.closePopup()">✕</button>
            </div>
            
            <div class="chat-tabs">
                <div class="chat-tab ${this.userType === 'admin' ? '' : 'user'} ${this.currentTab === 'public' ? 'active' : ''}" onclick="chatWidget.switchTab('public')">
                    عام
                </div>
                <div class="chat-tab ${this.userType === 'admin' ? '' : 'user'} ${this.currentTab === 'private' ? 'active' : ''}" onclick="chatWidget.switchTab('private')">
                    خاص
                </div>
            </div>
            
            <div id="privateUsersList" class="private-users-list" style="display: none;"></div>
            
            <div id="privateChatHeader" class="private-chat-header" style="display: none;">
                <button class="back-to-public" onclick="chatWidget.backToPublic()">←</button>
                <div id="selectedUserInfo" class="selected-user-info"></div>
            </div>
            
            <div class="chat-popup-content" id="chatMessages"></div>
            
            <div class="chat-popup-footer">
                <form id="chatForm" class="chat-input-form">
                    <input type="text" id="chatInput" class="chat-input" placeholder="اكتب رسالتك..." autocomplete="off">
                    <button type="submit" class="send-btn">➤</button>
                </form>
            </div>
        `;
        
        document.body.appendChild(this.widget);
        document.body.appendChild(this.popup);
    }
    
    addEventListeners() {
        this.widget.addEventListener('click', () => this.togglePopup());
        document.getElementById('chatForm').addEventListener('submit', (e) => this.sendMessage(e));
    }
    
    switchTab(tab) {
        this.currentTab = tab;
        
        document.querySelectorAll('.chat-tab').forEach(el => el.classList.remove('active'));
        event.target.classList.add('active');
        
        if (tab === 'public') {
            document.getElementById('privateUsersList').style.display = 'none';
            document.getElementById('privateChatHeader').style.display = 'none';
            this.currentPrivateUser = null;
            this.loadPublicMessages();
        } else {
            document.getElementById('privateUsersList').style.display = 'block';
            this.loadPrivateUsers();
        }
    }
    
    backToPublic() {
        this.switchTab('public');
    }
    
    async loadPrivateUsers() {
        const { data: users } = await this.supabase
            .from('users')
            .select('*')
            .neq('id', this.currentUser?.id)
            .order('full_name');
        
        const listElement = document.getElementById('privateUsersList');
        
        listElement.innerHTML = users.map(user => `
            <div class="private-user-item" onclick="chatWidget.selectPrivateUser('${user.id}')">
                <div class="user-avatar ${user.role === 'admin' ? '' : 'user'}">
                    ${(user.full_name || user.username).charAt(0)}
                </div>
                <div class="flex-1">
                    <div class="font-medium text-sm">${user.full_name || user.username}</div>
                    <div class="flex items-center gap-1 text-xs text-gray-500">
                        <span class="user-status ${this.onlineUsers[user.id] ? 'online' : 'offline'}"></span>
                        ${user.role === 'admin' ? '👑 مدير' : '👤 مستخدم'}
                    </div>
                </div>
                ${this.privateUnreadCount[user.id] ? `
                    <span class="bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                        ${this.privateUnreadCount[user.id]}
                    </span>
                ` : ''}
            </div>
        `).join('');
    }
    
    async selectPrivateUser(userId) {
        this.currentPrivateUser = userId;
        
        const { data: user } = await this.supabase
            .from('users')
            .select('*')
            .eq('id', userId)
            .single();
        
        document.getElementById('privateUsersList').style.display = 'none';
        document.getElementById('privateChatHeader').style.display = 'flex';
        document.getElementById('selectedUserInfo').innerHTML = `
            <div class="user-avatar ${user.role === 'admin' ? '' : 'user'}">
                ${(user.full_name || user.username).charAt(0)}
            </div>
            <div>
                <div class="font-bold text-sm">${user.full_name || user.username}</div>
                <div class="flex items-center gap-1 text-xs text-gray-600">
                    <span class="user-status ${this.onlineUsers[userId] ? 'online' : 'offline'}"></span>
                    ${user.role === 'admin' ? 'مدير' : 'مستخدم'}
                </div>
            </div>
        `;
        
        await this.loadPrivateMessages(userId);
        
        if (this.privateUnreadCount[userId]) {
            this.privateUnreadCount[userId] = 0;
            this.updatePrivateBadge();
        }
    }
    
    // ✅ دالة تحميل الرسائل الخاصة (معدلة)
    async loadPrivateMessages(otherUserId) {
        const container = document.getElementById('chatMessages');
        if (!container) return;
        
        container.innerHTML = '<div class="text-center text-gray-500 p-4">جاري تحميل الرسائل...</div>';
        
        try {
            const { data: messages, error } = await this.supabase
                .from('private_messages')
                .select('*')
                .or(`and(sender_id.eq.${this.currentUser.id},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${this.currentUser.id})`)
                .order('created_at', { ascending: true });
            
            if (error) throw error;
            
            container.innerHTML = '';
            
            if (!messages || messages.length === 0) {
                container.innerHTML = '<div class="text-center text-gray-500 p-4">لا توجد رسائل خاصة بعد</div>';
                return;
            }
            
            messages.forEach(msg => {
                const messageData = {
                    id: msg.id,
                    content: msg.content || '',
                    file_url: msg.file_url,
                    file_type: msg.file_type,
                    file_name: msg.file_name,
                    created_at: msg.created_at,
                    sender_id: msg.sender_id,
                    receiver_id: msg.receiver_id,
                    sender_name: msg.sender_name || (msg.sender_id === this.currentUser.id ? this.currentUser.full_name : 'مستخدم'),
                    sender_role: msg.sender_role || 'user'
                };
                
                const isMine = msg.sender_id === this.currentUser.id;
                this.displayPrivateMessage(messageData, isMine);
            });
            
        } catch (error) {
            console.error('خطأ في تحميل الرسائل الخاصة:', error);
            container.innerHTML = '<div class="text-center text-red-500 p-4">خطأ في تحميل الرسائل</div>';
        }
    }
    
    // ✅ دالة تحميل الرسائل العامة
    async loadPublicMessages() {
        const container = document.getElementById('chatMessages');
        if (!container) return;
        
        container.innerHTML = '<div class="text-center text-gray-500 p-4">جاري تحميل الرسائل...</div>';
        
        try {
            console.log('📥 جاري تحميل الرسائل من قاعدة البيانات...');
            
            const { data: messages, error } = await this.supabase
                .from('messages')
                .select('*')
                .order('created_at', { ascending: true })
                .limit(50);
            
            if (error) throw error;
            
            container.innerHTML = '';
            
            if (!messages || messages.length === 0) {
                container.innerHTML = '<div class="text-center text-gray-500 p-4">لا توجد رسائل بعد</div>';
                return;
            }
            
            console.log(`✅ تم تحميل ${messages.length} رسالة`);
            
            messages.forEach(msg => {
                this.displayMessage({
                    id: msg.id,
                    user_id: msg.user_id,
                    user_name: msg.user_name,
                    user_role: msg.user_role,
                    content: msg.content || '',
                    file_url: msg.file_url,
                    file_type: msg.file_type,
                    file_name: msg.file_name,
                    timestamp: msg.created_at
                }, msg.user_id === this.currentUser?.id);
            });
            
        } catch (error) {
            console.error('❌ خطأ في تحميل الرسائل:', error);
            container.innerHTML = '<div class="text-center text-red-500 p-4">خطأ في تحميل الرسائل</div>';
        }
    }
    
    async loadUserData() {
        try {
            const { data: { user } } = await this.supabase.auth.getUser();
            if (!user) return;
            
            const { data: userData } = await this.supabase
                .from('users')
                .select('*')
                .eq('id', user.id)
                .single();
            
            if (userData) {
                this.currentUser = userData;
                this.requestNotificationPermission();
                this.initRealtime();
                
                await this.loadPublicMessages();
            }
        } catch (error) {
            console.error('خطأ في تحميل المستخدم:', error);
        }
    }
    
    requestNotificationPermission() {
        if ("Notification" in window) {
            if (Notification.permission !== "granted" && Notification.permission !== "denied") {
                Notification.requestPermission();
            }
        }
    }
    
    openChatPopup() {
        if (!this.isOpen) this.togglePopup();
    }
    
    showNotification(message, sender) {
        if (!("Notification" in window)) return;
        
        if (Notification.permission === "granted") {
            new Notification("💬 رسالة جديدة", {
                body: `${sender}: ${message}`,
                icon: "/favicon.ico"
            });
        }
    }
    
    initRealtime() {
        this.presenceChannel = this.supabase.channel('online-users', {
            config: { presence: { key: this.currentUser.id } }
        });
        
        this.supabase
            .from('users')
            .update({ is_online: true, last_seen: new Date().toISOString() })
            .eq('id', this.currentUser.id)
            .then(({ error }) => {
                if (error) {
                    console.warn('⚠️ تحديث حالة الاتصال غير متاح:', error.message);
                } else {
                    console.log('✅ تم تحديث حالة الاتصال');
                }
            });
            
        this.presenceChannel
            .on('presence', { event: 'sync' }, () => {
                const state = this.presenceChannel.presenceState();
                this.updateOnlineUsers(state);
            })
            .subscribe(async (status) => {
                if (status === 'SUBSCRIBED') {
                    await this.presenceChannel.track({
                        user_id: this.currentUser.id,
                        user_name: this.currentUser.full_name || this.currentUser.username,
                        user_role: this.currentUser.role
                    });
                }
            });
        
        this.publicChannel = this.supabase.channel('public-chat', {
            config: { broadcast: { self: true } }
        });
        
        this.publicChannel
            .on('broadcast', { event: 'message' }, ({ payload }) => {
                this.receiveMessage(payload);
            })
            .subscribe();
        
        this.privateChannel = this.supabase.channel(`private-${this.currentUser.id}`, {
            config: { broadcast: { self: true } }
        });
        
        this.privateChannel
            .on('broadcast', { event: 'private-message' }, ({ payload }) => {
                this.receivePrivateMessage(payload);
            })
            .subscribe();
        
        window.addEventListener('beforeunload', () => this.cleanup());
    }
    
    updateOnlineUsers(presenceState) {
        this.onlineUsers = {};
        const users = Object.values(presenceState).flat();
        users.forEach(u => this.onlineUsers[u.user_id] = u);
        
        document.getElementById('onlineCount').textContent = users.length;
        
        if (this.currentTab === 'private') {
            this.loadPrivateUsers();
        }
    }
    
    togglePopup() {
        this.isOpen = !this.isOpen;
        if (this.isOpen) {
            this.popup.classList.add('open');
            this.unreadCount = 0;
            this.privateUnreadCount = {};
            document.getElementById('chatBadge').style.display = 'none';
            document.getElementById('privateChatBadge').style.display = 'none';
            this.loadPublicMessages();
        } else {
            this.popup.classList.remove('open');
        }
    }
    
    closePopup() {
        this.isOpen = false;
        this.popup.classList.remove('open');
    }
    
    async sendMessage(e) {
        e.preventDefault();
        
        const input = document.getElementById('chatInput');
        if (!input) return;
        
        const message = input.value.trim();
        if (!message || !this.currentUser) return;
        
        if (this.currentTab === 'public') {
            const messageData = {
                user_id: this.currentUser.id,
                user_name: this.currentUser.full_name || this.currentUser.username,
                user_role: this.currentUser.role,
                content: message,
                created_at: new Date().toISOString()
            };
            
            try {
                const { error } = await this.supabase
                    .from('messages')
                    .insert([messageData]);
                
                if (error) throw error;
                
                this.displayMessage(messageData, true);
                
                if (this.publicChannel) {
                    await this.publicChannel.send({
                        type: 'broadcast',
                        event: 'message',
                        payload: messageData
                    });
                }
                
                input.value = '';
                
            } catch (error) {
                console.error('خطأ في إرسال الرسالة:', error);
                alert('فشل إرسال الرسالة');
            }
            
        } else if (this.currentPrivateUser) {
            const messageData = {
                sender_id: this.currentUser.id,
                receiver_id: this.currentPrivateUser,
                content: message,
                file_url: null,
                file_type: null,
                file_name: null,
                sender_name: this.currentUser.full_name || this.currentUser.username,
                sender_role: this.currentUser.role,
                created_at: new Date().toISOString()
            };
            
            try {
                await this.supabase
                    .from('private_messages')
                    .insert([messageData]);
                
                await this.supabase.channel(`private-${this.currentPrivateUser}`).send({
                    type: 'broadcast',
                    event: 'private-message',
                    payload: messageData
                });
                
                this.displayPrivateMessage(messageData, true);
                
                input.value = '';
                
            } catch (error) {
                console.error('خطأ في إرسال الرسالة الخاصة:', error);
                alert('فشل إرسال الرسالة');
            }
        }
    }
    
    receiveMessage(message) {
        console.log('📩 رسالة جديدة واردة:', message);
        
        this.displayMessage(message, message.user_id === this.currentUser?.id);
        
        if (!this.isOpen || this.currentTab !== 'public') {
            this.unreadCount++;
            const badge = document.getElementById('chatBadge');
            if (badge) {
                badge.textContent = this.unreadCount;
                badge.style.display = 'flex';
            }
            
            this.openChatPopup();
            this.showNotification(message.content || '📎 ملف', message.user_name);
        }
    }
    
    receivePrivateMessage(message) {
        const isForMe = message.receiver_id === this.currentUser?.id;
        
        if (!this.isOpen || this.currentTab !== 'private' || this.currentPrivateUser !== message.sender_id) {
            this.privateUnreadCount[message.sender_id] = (this.privateUnreadCount[message.sender_id] || 0) + 1;
            this.updatePrivateBadge();
            
            this.openChatPopup();
            this.showNotification(message.content, message.sender_name || 'مستخدم');
            
            if (this.currentTab === 'private') {
                this.loadPrivateUsers();
            }
        }
        
        if (this.currentTab === 'private' && this.currentPrivateUser === message.sender_id) {
            this.displayPrivateMessage(message, false);
        }
    }
    
    updatePrivateBadge() {
        const total = Object.values(this.privateUnreadCount).reduce((a, b) => a + b, 0);
        if (total > 0) {
            document.getElementById('privateChatBadge').textContent = total;
            document.getElementById('privateChatBadge').style.display = 'flex';
        } else {
            document.getElementById('privateChatBadge').style.display = 'none';
        }
    }
    
    // ✅ دالة عرض الرسائل العامة
    displayMessage(message, isMine) {
        try {
            const messageId = message.id || message.timestamp || message.created_at;
            if (this.processedMessages.has(messageId)) {
                return;
            }
            this.processedMessages.add(messageId);

            const container = document.getElementById('chatMessages');
            if (!container) return;

            const messageDiv = document.createElement('div');
            messageDiv.className = `chat-message ${isMine ? 'sent' : 'received'}`;

            const time = new Date(message.timestamp || message.created_at).toLocaleTimeString('ar-EG', {
                hour: '2-digit',
                minute: '2-digit'
            });

            const roleIcon = message.user_role === 'admin' ? '👑' : '👤';

            let contentHtml = '';

            if (message.file_url) {
                if (message.file_type?.startsWith('image')) {
                    contentHtml += `
                        <div style="margin-bottom: 10px; text-align: center;">
                            <img src="${message.file_url}" 
                                 style="max-width: 200px; max-height: 200px; border-radius: 8px; cursor: pointer;"
                                 onclick="window.open('${message.file_url}', '_blank')"
                                 alt="صورة">
                        </div>`;
                } else {
                    const fileIcon = message.file_type?.includes('pdf') ? '📕' : 
                                    message.file_type?.includes('doc') ? '📘' : '📎';
                    contentHtml += `
                        <div style="margin-bottom: 5px;">
                            <a href="${message.file_url}" target="_blank" 
                               style="text-decoration: none; color: inherit; display: inline-block; padding: 5px 10px; background: #f0f0f0; border-radius: 5px;">
                                ${fileIcon} ${message.file_name || 'ملف مرفق'}
                            </a>
                        </div>`;
                }
            }

            if (message.content && message.content.trim() !== '') {
                contentHtml += `<div style="margin-top: ${message.file_url ? '5px' : '0'};">${message.content}</div>`;
            }

            if (!contentHtml) return;

            messageDiv.innerHTML = `
                <div class="message-bubble ${isMine ? 'sent' : 'received'}">
                    ${contentHtml}
                </div>
                <div class="message-info" style="font-size: 11px; margin-top: 4px; color: #666;">
                    <span>${roleIcon} ${message.user_name}</span> • <span>${time}</span>
                </div>
            `;

            container.appendChild(messageDiv);
            container.scrollTop = container.scrollHeight;

        } catch (error) {
            console.error('خطأ في عرض الرسالة:', error);
        }
    }
    
    // ✅ دالة عرض الرسائل الخاصة
    displayPrivateMessage(message, isMine) {
        try {
            const messageId = message.id || message.created_at;
            if (this.processedMessages.has(`priv_${messageId}`)) {
                return;
            }
            this.processedMessages.add(`priv_${messageId}`);
            
            const container = document.getElementById('chatMessages');
            if (!container) return;
            
            const messageDiv = document.createElement('div');
            messageDiv.className = `flex ${isMine ? 'justify-start' : 'justify-end'} mb-2`;
            
            const time = new Date(message.created_at).toLocaleTimeString('ar-EG', {
                hour: '2-digit',
                minute: '2-digit'
            });
            
            const senderName = message.sender_name || 
                              (isMine ? this.currentUser?.full_name || this.currentUser?.username : 'مستخدم');
            const roleIcon = message.sender_role === 'admin' ? '👑' : '👤';
            
            let contentHtml = '';
            
            if (message.file_url) {
                if (message.file_type?.startsWith('image')) {
                    contentHtml += `<div style="margin-bottom: 10px; text-align: center;">
                        <img src="${message.file_url}" 
                             style="max-width: 200px; max-height: 200px; border-radius: 8px; cursor: pointer;"
                             onclick="window.open('${message.file_url}', '_blank')">
                    </div>`;
                } else {
                    const fileIcon = message.file_type?.includes('pdf') ? '📕' : '📎';
                    contentHtml += `<div style="margin-bottom: 5px;">
                        <a href="${message.file_url}" target="_blank" 
                           style="text-decoration: none; color: inherit;">
                            ${fileIcon} ${message.file_name || 'ملف'}
                        </a>
                    </div>`;
                }
            }
            
            if (message.content && message.content.trim() !== '') {
                contentHtml += `<div style="margin-top: ${message.file_url ? '5px' : '0'};">${message.content}</div>`;
            }
            
            messageDiv.innerHTML = `
                <div style="max-width: 70%; padding: 10px; border-radius: 10px; 
                            background: ${isMine ? '#2f855a' : '#e5e7eb'}; 
                            color: ${isMine ? 'white' : 'black'};">
                    ${contentHtml}
                    <div style="font-size: 10px; margin-top: 5px; opacity: 0.8;">
                        ${roleIcon} ${senderName} • ${time}
                    </div>
                </div>
            `;
            
            container.appendChild(messageDiv);
            container.scrollTop = container.scrollHeight;
            
        } catch (error) {
            console.error('خطأ في عرض الرسالة الخاصة:', error);
        }
    }
    
    async cleanup() {
        if (this.presenceChannel) {
            await this.presenceChannel.untrack();
            await this.supabase
                .from('users')
                .update({ is_online: false })
                .eq('id', this.currentUser?.id);
            await this.presenceChannel.unsubscribe();
        }
        if (this.publicChannel) {
            await this.publicChannel.unsubscribe();
        }
        if (this.privateChannel) {
            await this.privateChannel.unsubscribe();
        }
    }
}

let chatWidget;

document.addEventListener('DOMContentLoaded', () => {
    const isAdmin = window.location.pathname.includes('/ADMIN/');
    chatWidget = new ChatWidget(isAdmin ? 'admin' : 'user');
});