// ============================================
// ملف المصادقة والمستخدم
// ============================================

let currentUser = null;

// تحميل بيانات المستخدم
async function loadUserProfile() {
    try {
        const { data: { user } } = await supabaseClient.auth.getUser();
        
        if (!user) {
            window.location.href = 'login.html';
            return null;
        }

        const { data: userData } = await supabaseClient
            .from('users')
            .select('*')
            .eq('id', user.id)
            .single();

        if (userData) {
            currentUser = userData;
            updateProfileUI(userData);
        }
        
        return userData;
    } catch (error) {
        console.error('خطأ في تحميل المستخدم:', error);
        return null;
    }
}

// تحديث واجهة المستخدم
function updateProfileUI(userData) {
    const displayName = userData.full_name || userData.username || 'مستخدم';
    const nameEl = document.getElementById('profileName');
    const initialEl = document.getElementById('profileInitial');
    const roleEl = document.getElementById('profileRole');
    
    if (nameEl) nameEl.textContent = displayName;
    if (initialEl) initialEl.textContent = displayName.charAt(0);
    if (roleEl) roleEl.textContent = userData.role === 'admin' ? 'مدير النظام' : 'مستخدم';
}

// تسجيل الخروج
async function logout() {
    await supabaseClient.auth.signOut();
    window.location.href = 'index.html';
}

// التحقق إذا كان المستخدم مدير
function isAdmin() {
    return currentUser && currentUser.role === 'admin';
}

window.loadUserProfile = loadUserProfile;
window.logout = logout;
window.isAdmin = isAdmin;
window.currentUser = currentUser;