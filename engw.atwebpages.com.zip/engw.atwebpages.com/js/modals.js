// ============================================
// ملف المودالات - modals.js (النسخة المعدلة النهائية)
// ============================================


 // فتح مودال التعديل - نسخة مع تحديد الحقول القابلة للتعديل
// فتح مودال التعديل - نسخة مع تحديد الحقول القابلة للتعديل
function editRequest(id) {
    console.log('🔧 محاولة فتح مودال التعديل للطلب:', id);
    closeDetailsModal();
    
    const request = allRequests.find(r => r.id == id);
    if (!request) {
        console.error('❌ الطلب غير موجود:', id);
        return;
    }

    console.log('📦 بيانات الطلب:', request);
    console.log('📊 حالة الطلب:', request.Status);

    // التحقق من إمكانية التعديل
    const requestStatus = (request.Status || '').toLowerCase().trim();
    console.log('🔍 الحالة بعد التحويل:', requestStatus);
    
    const allowedStatuses = ['on request', 'on request new code'];
    const isEditable = allowedStatuses.some(status => requestStatus.includes(status));
    
    console.log('✅ قابل للتعديل؟', isEditable);
    
    if (!isEditable) {
        console.log('ℹ️ فتح وضع العرض فقط');
        openDetailsModal(id);
        return;
    }

    console.log('✏️ فتح مودال التعديل...');
    
    // ✅ التحقق من وجود كل عنصر على حدة ومعرفة أيهم المفقود
    const requestDateEl = document.getElementById('requestDate');
    const actionDateEl = document.getElementById('actionDate');
    const statusSelectEl = document.getElementById('status');
    const modalTitleEl = document.getElementById('modalTitle');
    const requestIdEl = document.getElementById('requestId');
    const quantityEl = document.getElementById('quantity');
    const typeEl = document.getElementById('type');
    const unitsEl = document.getElementById('units');
    
    // فحص كل عنصر
    console.log('🔍 فحص العناصر:');
    console.log('- requestDate:', requestDateEl ? 'موجود' : '❌ غير موجود');
    console.log('- actionDate:', actionDateEl ? 'موجود' : '❌ غير موجود');
    console.log('- status:', statusSelectEl ? 'موجود' : '❌ غير موجود');
    console.log('- modalTitle:', modalTitleEl ? 'موجود' : '❌ غير موجود');
    console.log('- requestId:', requestIdEl ? 'موجود' : '❌ غير موجود');
    
    if (!requestDateEl || !actionDateEl || !statusSelectEl || !modalTitleEl || !requestIdEl) {
        console.error('❌ بعض عناصر المودال غير موجودة');
        return;
    }

    modalTitleEl.textContent = '✏️ تعديل الطلب';
    requestIdEl.value = request.id;
    
    // ✅ أولاً: جعل جميع الحقول readonly
    const allFields = [
        'requestDate', 'requestedBy', 'groups', 'requestingPerson', 'request',
        'code', 'sample', 'attach', 'link', 'units', 'quantity', 'machine',
        'building', 'grade', 'project', 'notesReject', 'pr', 'actionDate',
        'actionManager', 'actionOracle', 'email', 'actualQuantity', 'type',
        'priceCalculation', 'newPrice'
    ];
    
    allFields.forEach(fieldId => {
        const el = document.getElementById(fieldId);
        if (el) {
            el.setAttribute('readonly', true);
            el.style.backgroundColor = '#f3f4f6';
            el.style.cursor = 'not-allowed';
            el.disabled = false; // التأكد من أن disabled غير مفعل
        }
    });
    
    // ✅ ثم نحدد الحقول القابلة للتعديل فقط (الكمية والنوع)
    
    // الكمية (quantity) - قابلة للتعديل
    if (quantityEl) {
        quantityEl.removeAttribute('readonly');
        quantityEl.style.backgroundColor = '';
        quantityEl.style.cursor = 'text';
    }
    
    // النوع (type) - قابل للتعديل
    if (typeEl) {
        typeEl.removeAttribute('readonly');
        typeEl.style.backgroundColor = '';
        typeEl.style.cursor = 'text';
    }
    
    // الوحدات (units) - قابلة للتعديل أيضاً
    if (unitsEl) {
        unitsEl.removeAttribute('readonly');
        unitsEl.style.backgroundColor = '';
        unitsEl.style.cursor = 'text';
    }
    
    // ✅ Status - غير قابل للتعديل للجميع (حتى المدير)
    if (statusSelectEl) {
        statusSelectEl.disabled = true;
        statusSelectEl.style.backgroundColor = '#f3f4f6';
        statusSelectEl.style.cursor = 'not-allowed';
        statusSelectEl.style.pointerEvents = 'none';
        statusSelectEl.removeEventListener('change', handleStatusChange);
    }
    
    // ✅ Action Manager - غير قابل للتعديل
    const actionManagerEl = document.getElementById('actionManager');
    if (actionManagerEl) {
        actionManagerEl.setAttribute('readonly', true);
        actionManagerEl.style.backgroundColor = '#f3f4f6';
        actionManagerEl.style.cursor = 'not-allowed';
    }
    
    // ✅ Action Oracle - غير قابل للتعديل
    const actionOracleEl = document.getElementById('actionOracle');
    if (actionOracleEl) {
        actionOracleEl.setAttribute('readonly', true);
        actionOracleEl.style.backgroundColor = '#f3f4f6';
        actionOracleEl.style.cursor = 'not-allowed';
    }
    
    // ✅ Request Date
    requestDateEl.value = convertToDateInputFormat(request['Request Date']) || '';
    
    // ✅ Action Date - تاريخ اليوم
    const today = new Date().toISOString().split('T')[0];
    actionDateEl.value = today;
    
    // ✅ تعبئة باقي الحقول
    const fields = {
        requestedBy: request['Requested by'],
        groups: request.groups,
        requestingPerson: request['Requesting person'],
        request: request.Request,
        code: request.code,
        sample: request.sample,
        attach: request.Attach,
        link: request.Link,
        units: request.Units,
        quantity: request.Quantity,
        machine: request.Machine,
        building: request.Building,
        grade: request.Grade,
        project: request.Project,
        notesReject: request['Notes Reject'],
        pr: request.pr,
        email: request.Email,
        actualQuantity: request['Actual Quantity'],
        type: request.Type,
        priceCalculation: request['Price calculation'],
        newPrice: request['New Price']
    };
    
    Object.keys(fields).forEach(field => {
        const el = document.getElementById(field);
        if (el) {
            el.value = fields[field] || '';
        }
    });
    
    // ✅ Status - نضع القيمة بعد التعبئة
    if (statusSelectEl) {
        statusSelectEl.value = request.Status || 'ON Request';
    }

    // فتح المودال
    const modal = document.getElementById('requestModal');
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
    
    console.log('✅ تم فتح مودال التعديل بنجاح');
    console.log('📝 الحقول القابلة للتعديل فقط: quantity, type, units');
}
// فتح مودال الإضافة
function openAddModal() {
    document.getElementById('modalTitle').textContent = '➕ إضافة طلب جديد';
    document.getElementById('requestForm').reset();
    document.getElementById('requestId').value = '';
    
    // إزالة خاصية readonly من جميع الحقول في حالة الإضافة
    const allFields = [
        'requestDate', 'requestedBy', 'groups', 'requestingPerson', 'request',
        'code', 'sample', 'attach', 'link', 'units', 'quantity', 'machine',
        'building', 'grade', 'project', 'notesReject', 'pr', 'actionDate',
        'actionManager', 'actionOracle', 'email', 'actualQuantity', 'type',
        'priceCalculation', 'newPrice'
    ];
    
    allFields.forEach(fieldId => {
        const el = document.getElementById(fieldId);
        if (el) {
            el.removeAttribute('readonly');
            el.style.backgroundColor = '';
            el.style.cursor = 'text';
        }
    });
    
    // تعيين تاريخ اليوم كقيمة افتراضية للإضافة
    const today = new Date().toISOString().split('T')[0];
    const requestDateEl = document.getElementById('requestDate');
    const actionDateEl = document.getElementById('actionDate');
    
    if (requestDateEl) requestDateEl.value = today;
    if (actionDateEl) actionDateEl.value = today;
    
    // تعيين الحالة الافتراضية
    const statusSelect = document.getElementById('status');
    if (statusSelect) statusSelect.value = 'ON Request';
    
    document.getElementById('requestModal').classList.add('open');
    document.body.style.overflow = 'hidden';
}

// فتح مودال التفاصيل
function openDetailsModal(id) {
    const request = allRequests.find(r => r.id == id);
    if (!request) return;

    let detailsHtml = '';
    for (let col of columns) {
        let value = request[col.field];
        
        if (col.field === 'Request Date' || col.field === 'Action Date') {
            value = value || '—';
        } else if (col.field === 'Status') {
            value = formatStatus(value);
        } else {
            value = value || '—';
        }
        
        detailsHtml += `
            <div class="detail-item">
                <div class="detail-label">${col.label}</div>
                <div class="detail-value">${value}</div>
            </div>
        `;
    }
    
    document.getElementById('detailsContent').innerHTML = detailsHtml;
    
    const modalActions = document.getElementById('modalActions');
    const isAdmin = currentUser && currentUser.role === 'admin';
    const requestStatus = (request.Status || '').toLowerCase().trim();
    
    // ✅ قائمة الحالات المسموح بها للتعديل (بصيغة lowercase للمقارنة)
    const allowedStatuses = [
        'on request',
        'on request new code'
    ];
    
    const isEditable = allowedStatuses.some(status => requestStatus.includes(status));
    
    let actionsHtml = '';
    if (isEditable) {
        actionsHtml += `<button class="modal-btn modal-btn-edit" onclick="editRequest('${request.id}')"><i class="fas fa-edit ml-1"></i> تعديل</button>`;
    }
    if (isAdmin) {
        actionsHtml += `<button class="modal-btn modal-btn-delete" onclick="openDeleteModal('${request.id}')"><i class="fas fa-trash ml-1"></i> حذف</button>`;
    }
    actionsHtml += `<button class="modal-btn modal-btn-close" onclick="closeDetailsModal()"><i class="fas fa-times ml-1"></i> إغلاق</button>`;
    
    modalActions.innerHTML = actionsHtml;
    document.getElementById('detailsModal').classList.add('open');
}

function closeDetailsModal() {
    document.getElementById('detailsModal').classList.remove('open');
    document.getElementById('modalActions').innerHTML = '';
}

function closeModal() {
    document.getElementById('requestModal').classList.remove('open');
    document.body.style.overflow = 'auto';
}

// حفظ الطلب
document.getElementById('requestForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = {
        'Request Date': document.getElementById('requestDate').value || null,
        'Requested by': document.getElementById('requestedBy').value,
        'groups': document.getElementById('groups').value || null,
        'Requesting person': document.getElementById('requestingPerson').value || null,
        'Request': document.getElementById('request').value || null,
        'code': document.getElementById('code').value || null,
        'sample': document.getElementById('sample').value || null,
        'Attach': document.getElementById('attach').value || null,
        'Link': document.getElementById('link').value || null,
        'Units': document.getElementById('units').value || null,
        'Quantity': parseFloat(document.getElementById('quantity').value) || null,
        'Machine': document.getElementById('machine').value || null,
        'Building': document.getElementById('building').value || null,
        'Grade': document.getElementById('grade').value || null,
        'Project': document.getElementById('project').value || null,
        'Status': document.getElementById('status').value,
        'Notes Reject': document.getElementById('notesReject').value || null,
        'pr': document.getElementById('pr').value || null,
        'Action Date': document.getElementById('actionDate').value || null,
        'Action Manager': document.getElementById('actionManager').value || null,
        'Action Oracle': document.getElementById('actionOracle').value || null,
        'Email': document.getElementById('email').value || null,
        'Actual Quantity': parseFloat(document.getElementById('actualQuantity').value) || null,
        'Type': document.getElementById('type').value || null,
        'Price calculation': document.getElementById('priceCalculation').value || null,
        'New Price': parseFloat(document.getElementById('newPrice').value) || null
    };

    const id = document.getElementById('requestId').value;

    try {
        let error;
        
        if (id) {
            ({ error } = await window.supabaseClient
                .from('الطلبات')
                .update(formData)
                .eq('id', id));
        } else {
            ({ error } = await window.supabaseClient
                .from('الطلبات')
                .insert([formData]));
        }

        if (error) throw error;

        closeModal();
        await loadRequests();
        showSuccess(id ? 'تم التحديث بنجاح' : 'تمت الإضافة بنجاح');

    } catch (error) {
        console.error('خطأ:', error);
        showError('فشل في حفظ البيانات: ' + error.message);
    }
});

// مودال الحذف
function openDeleteModal(id) {
    window.deleteId = id;
    document.getElementById('deleteModal').classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeDeleteModal() {
    document.getElementById('deleteModal').classList.remove('open');
    document.body.style.overflow = 'auto';
    window.deleteId = null;
}

async function confirmDelete() {
    try {
        const { error } = await window.supabaseClient
            .from('الطلبات')
            .delete()
            .eq('id', window.deleteId);

        if (error) throw error;

        closeDeleteModal();
        closeDetailsModal();
        await loadRequests();
        showSuccess('تم الحذف بنجاح');

    } catch (error) {
        console.error('خطأ:', error);
        showError('فشل في الحذف: ' + error.message);
    }
}

// دالة formatDate
function formatDate(dateStr) {
    if (!dateStr) return '—';
    
    if (typeof dateStr === 'string' && dateStr.includes('/')) {
        return dateStr;
    }
    
    try {
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return dateStr;
        return date.toLocaleDateString('ar-EG');
    } catch {
        return dateStr;
    }
}

// دالة formatStatus (نسخة واحدة فقط)
function formatStatus(status) {
    if (!status) return '<span class="status-badge status-pending">—</span>';
    const s = status.toLowerCase();
    
    if (s.includes('on request new code')) 
        return '<span class="status-badge status-on-request-new">ON Request New Code</span>';
    if (s.includes('on request')) 
        return '<span class="status-badge status-on-request">ON Request</span>';
    if (s.includes('oracle done')) 
        return '<span class="status-badge status-oracle-done">Oracle Done</span>';
    if (s.includes('reject data incomplete oracle')) 
        return '<span class="status-badge status-reject-incomplete">Reject data incomplete Oracle</span>';
    if (s.includes('reject')) 
        return '<span class="status-badge status-reject">Reject</span>';
    if (s.includes('manager done')) 
        return '<span class="status-badge status-manager-done">Manager Done</span>';
    
    return '<span class="status-badge status-pending">' + status + '</span>';
}

// تصدير الدوال
window.openDetailsModal = openDetailsModal;
window.closeDetailsModal = closeDetailsModal;
window.openAddModal = openAddModal;
window.closeModal = closeModal;
window.editRequest = editRequest;
window.openDeleteModal = openDeleteModal;
window.closeDeleteModal = closeDeleteModal;
window.confirmDelete = confirmDelete;
window.handleStatusChange = handleStatusChange;
window.formatStatus = formatStatus;

console.log('✅ تم تحميل ملف modals.js بنجاح');