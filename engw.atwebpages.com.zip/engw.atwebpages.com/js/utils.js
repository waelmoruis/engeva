// ============================================
// الدوال المساعدة
// ============================================

// تنسيق التاريخ
function formatDate(dateStr) {
    if (!dateStr) return '—';
    try {
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return dateStr;
        return date.toLocaleDateString('ar-EG');
    } catch {
        return dateStr;
    }
}

// تنسيق الحالة
function formatStatus(status) {
    if (!status) return '<span class="status-badge status-pending">—</span>';
    const s = status.toLowerCase();
    
    if (s.includes('on request new code')) 
        return '<span class="status-badge status-on-request-new">ON Request New Code</span>';
    if (s.includes('on request')) 
        return '<span class="status-badge status-on-request">ON Request</span>';
    if (s.includes('oracle done')) 
        return '<span class="status-badge status-oracle-done">Oracle Done</span>';
    if (s.includes('reject data incomplete oracle')) 
        return '<span class="status-badge status-reject-incomplete">Reject data incomplete Oracle</span>';
    if (s.includes('reject')) 
        return '<span class="status-badge status-reject">Reject</span>';
    if (s.includes('pending eng new code')) 
        return '<span class="status-badge status-pending-eng-new">Pending Eng New Code</span>';
    if (s.includes('pending eng')) 
        return '<span class="status-badge status-pending-eng">Pending Eng</span>';
    if (s.includes('waiting for coding')) 
        return '<span class="status-badge status-waiting-coding">Waiting for coding</span>';
    if (s.includes('waiting budget')) 
        return '<span class="status-badge status-waiting-budget">Waiting Budget</span>';
    if (s.includes('pending approval')) 
        return '<span class="status-badge status-pending-approval">Pending Approval</span>';
    if (s.includes('manager done')) 
        return '<span class="status-badge status-manager-done">Manager Done</span>';
    if (s.includes('approve')) 
        return '<span class="status-badge status-approved">معتمد</span>';
    if (s.includes('complete')) 
        return '<span class="status-badge status-completed">مكتمل</span>';
    if (s.includes('added') || s.includes('store')) 
        return '<span class="status-badge status-added">Added to store</span>';
    
    return '<span class="status-badge status-pending">' + status + '</span>';
}

// عرض رسالة خطأ
function showError(msg) {
    const div = document.getElementById('errorMessage');
    if (div) {
        div.textContent = msg;
        div.classList.remove('hidden');
        setTimeout(() => div.classList.add('hidden'), 3000);
    }
}

// عرض رسالة نجاح
function showSuccess(msg) {
    const div = document.getElementById('successMessage');
    if (div) {
        div.textContent = msg;
        div.classList.remove('hidden');
        setTimeout(() => div.classList.add('hidden'), 3000);
    }
}

// جعل الدوال متاحة في النطاق العام
window.formatDate = formatDate;
window.formatStatus = formatStatus;
window.showError = showError;
window.showSuccess = showSuccess;