// ============================================
// ملف القائمة الجانبية
// ============================================

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    const mainContent = document.getElementById('mainContent');
    
    sidebar.classList.toggle('open');
    overlay.classList.toggle('open');
    
    if (window.innerWidth > 768) {
        mainContent.classList.toggle('sidebar-open');
    }
    
    document.body.style.overflow = sidebar.classList.contains('open') ? 'hidden' : 'auto';
}

function closeSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    const mainContent = document.getElementById('mainContent');
    
    sidebar.classList.remove('open');
    overlay.classList.remove('open');
    mainContent.classList.remove('sidebar-open');
    document.body.style.overflow = 'auto';
}

// إغلاق السايدبار عند تغيير حجم الشاشة
window.addEventListener('resize', function() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    if (window.innerWidth > 768 && sidebar.classList.contains('open')) {
        mainContent.classList.add('sidebar-open');
    } else {
        mainContent.classList.remove('sidebar-open');
    }
});

window.toggleSidebar = toggleSidebar;
window.closeSidebar = closeSidebar;