// ============================================
// ملف إدارة الأعمدة
// ============================================

// قائمة الأعمدة
const columns = [
    { field: 'id', label: 'ID', visible: true, class: 'col-id' },
    { field: 'Request Date', label: 'تاريخ الطلب', visible: true, class: 'col-date' },
    { field: 'Requested by', label: 'مقدم الطلب', visible: true, class: 'col-name' },
    { field: 'groups', label: 'المجموعة', visible: true, class: 'col-text' },
    { field: 'Requesting person', label: 'الشخص الطالب', visible: true, class: 'col-name' },
    { field: 'Request', label: 'الطلب', visible: true, class: 'col-request' },
    { field: 'code', label: 'الكود', visible: true, class: 'col-code' },
    { field: 'sample', label: 'العينة', visible: false, class: 'col-text' },
    { field: 'Attach', label: 'المرفقات', visible: false, class: 'col-text' },
    { field: 'Link', label: 'الرابط', visible: false, class: 'col-text' },
    { field: 'Units', label: 'الوحدة', visible: true, class: 'col-text' },
    { field: 'Quantity', label: 'الكمية', visible: true, class: 'col-quantity' },
    { field: 'Machine', label: 'الماكينة', visible: true, class: 'col-text' },
    { field: 'Building', label: 'المبنى', visible: true, class: 'col-text' },
    { field: 'Grade', label: 'الدرجة', visible: true, class: 'col-text' },
    { field: 'Project', label: 'المشروع', visible: true, class: 'col-text' },
    { field: 'Status', label: 'الحالة', visible: true, class: 'col-status' },
    { field: 'Notes Reject', label: 'ملاحظات الرفض', visible: false, class: 'col-text' },
    { field: 'pr', label: 'PR', visible: true, class: 'col-code' },
    { field: 'Action Date', label: 'تاريخ الإجراء', visible: true, class: 'col-date' },
    { field: 'Action Manager', label: 'المدير', visible: true, class: 'col-name' },
    { field: 'Action Oracle', label: 'Oracle', visible: false, class: 'col-text' },
    { field: 'Email', label: 'البريد', visible: true, class: 'col-text' },
    { field: 'Actual Quantity', label: 'الكمية الفعلية', visible: false, class: 'col-quantity' },
    { field: 'Type', label: 'النوع', visible: true, class: 'col-text' },
    { field: 'Price calculation', label: 'حساب السعر', visible: false, class: 'col-text' },
    { field: 'New Price', label: 'السعر الجديد', visible: false, class: 'col-quantity' }
];

window.columns = columns;

// رسم قائمة الأعمدة
function renderColumnList() {
    console.log('🔄 تنفيذ renderColumnList');
    const list = document.getElementById('columnList');
    if (!list) {
        console.warn('⚠️ عنصر columnList غير موجود');
        return;
    }
    
    list.innerHTML = '';
    
    columns.forEach((col, index) => {
        const item = document.createElement('div');
        item.className = 'column-item';
        item.innerHTML = `
            <input type="checkbox" ${col.visible ? 'checked' : ''} onchange="toggleColumnVisibility(${index})">
            <label onclick="toggleColumnVisibility(${index})">${col.label}</label>
            <div class="column-actions">
                <button class="move-btn" onclick="moveColumn(${index}, 'up')" ${index === 0 ? 'disabled' : ''}>
                    <i class="fas fa-arrow-up"></i>
                </button>
                <button class="move-btn" onclick="moveColumn(${index}, 'down')" ${index === columns.length - 1 ? 'disabled' : ''}>
                    <i class="fas fa-arrow-down"></i>
                </button>
            </div>
        `;
        list.appendChild(item);
    });
    
    updateSelectedCount();
}

// تبديل رؤية العمود
function toggleColumnVisibility(index) {
    columns[index].visible = !columns[index].visible;
    renderColumnList();
    if (typeof window.renderTable === 'function') {
        window.renderTable(window.filteredRequests || []);
    }
}

// تحريك العمود
function moveColumn(index, direction) {
    if (direction === 'up' && index > 0) {
        [columns[index], columns[index - 1]] = [columns[index - 1], columns[index]];
    } else if (direction === 'down' && index < columns.length - 1) {
        [columns[index], columns[index + 1]] = [columns[index + 1], columns[index]];
    }
    renderColumnList();
    if (typeof window.renderTable === 'function') {
        window.renderTable(window.filteredRequests || []);
    }
}

// إظهار كل الأعمدة
function showAllColumns() {
    columns.forEach(col => col.visible = true);
    renderColumnList();
    if (typeof window.renderTable === 'function') {
        window.renderTable(window.filteredRequests || []);
    }
}

// إخفاء كل الأعمدة
function hideAllColumns() {
    columns.forEach(col => col.visible = false);
    renderColumnList();
    if (typeof window.renderTable === 'function') {
        window.renderTable(window.filteredRequests || []);
    }
}

// استعادة الأعمدة الافتراضية
function resetDefaultColumns() {
    const defaultVisible = [
        true, true, true, true, true, true, true, false, false, false,
        true, true, true, true, true, true, true, false, true, true,
        true, false, true, false, true, false, false
    ];
    
    columns.forEach((col, index) => {
        col.visible = defaultVisible[index];
    });
    
    renderColumnList();
    if (typeof window.renderTable === 'function') {
        window.renderTable(window.filteredRequests || []);
    }
}

// تحديث عداد الأعمدة المختارة
function updateSelectedCount() {
    const visibleCount = columns.filter(c => c.visible).length;
    const visibleEl = document.getElementById('visibleCount');
    const selectedEl = document.getElementById('selectedColumnsCount');
    
    if (visibleEl) visibleEl.textContent = `${visibleCount}/${columns.length}`;
    if (selectedEl) selectedEl.textContent = `${visibleCount} أعمدة مختارة`;
}

// تبديل قائمة الأعمدة المنسدلة
function toggleColumnDropdown() {
    const dropdown = document.getElementById('columnDropdown');
    const btn = document.getElementById('columnSelectorBtn');
    if (dropdown && btn) {
        dropdown.classList.toggle('show');
        btn.classList.toggle('active');
    }
}

// إغلاق dropdown عند النقر خارجها
document.addEventListener('click', function(e) {
    const dropdown = document.getElementById('columnDropdown');
    const btn = document.getElementById('columnSelectorBtn');
    if (dropdown && btn && !btn.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.remove('show');
        btn.classList.remove('active');
    }
});

window.renderColumnList = renderColumnList;
window.toggleColumnVisibility = toggleColumnVisibility;
window.moveColumn = moveColumn;
window.showAllColumns = showAllColumns;
window.hideAllColumns = hideAllColumns;
window.resetDefaultColumns = resetDefaultColumns;
window.toggleColumnDropdown = toggleColumnDropdown;